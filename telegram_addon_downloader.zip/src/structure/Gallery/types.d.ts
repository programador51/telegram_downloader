import { CrawledImageDom } from "../../typesContentScript";

export interface PropsGallery {
  items: CrawledImageDom[];
}
