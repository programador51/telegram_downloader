export interface PropsImageDetected {
  blobSrc: string;
  sentAt: number;
  width:number;
  height:number;
}
