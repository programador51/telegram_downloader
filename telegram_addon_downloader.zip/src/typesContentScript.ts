export interface CrawledImageDom {
  blob: string;
  width: number;
  height: number;
}
