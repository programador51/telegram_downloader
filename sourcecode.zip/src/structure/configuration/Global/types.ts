export interface PropsGlobal {
  children: JSX.Element | JSX.Element[];
}
